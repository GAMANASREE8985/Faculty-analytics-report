import React from "react";

function DashboardSection({ employeeData }) {

  const emp =
    employeeData.employee?.[0] || {};

  const artifact =
    employeeData.artifacts?.[0] || {};

  const analyticsCards = [

    {
      title: "Total Sessions",
      value: employeeData.sessions.length,
      icon: "📚"
    },

    {
      title: "Completed",
      value:
        employeeData.sessions.filter(
          (s) =>
            s.session_status ===
            "Completed"
        ).length,
      icon: "✅"
    },

    {
      title: "Pending",
      value:
        employeeData.sessions.filter(
          (s) =>
            s.session_status ===
            "Pending"
        ).length,
      icon: "⏳"
    },

    {
      title: "Artifacts",
      value: artifact.grand_total || 0,
      icon: "📊"
    }

  ];

  return (

    <div className="dashboard-container">

      {/* HERO SECTION */}

      <div className="dashboard-hero">

        <div>

          <h1>
            Faculty Analytics Dashboard
          </h1>

          <p>
            Monitor faculty sessions,
            analytics, employee roles,
            and performance insights
            in one centralized portal.
          </p>

        </div>

      </div>

      {/* PROFILE CARD */}

      <div className="profile-card">

        <div className="profile-left">

          <div className="profile-avatar">

            {emp.name?.charAt(0)}

          </div>

          <div>

            <h2>{emp.name}</h2>

            <p>
              Faculty Member
            </p>

          </div>

        </div>

        <div className="profile-details">

          <p>
            <strong>ID:</strong>
            {emp.emp_id}
          </p>

          <p>
            <strong>Mail:</strong>
            {emp.mail}
          </p>

          <p>
            <strong>Type:</strong>
            {emp.type}
          </p>

          <p>
            <strong>City:</strong>
            {emp.city}
          </p>

        </div>

      </div>

      {/* ANALYTICS CARDS */}

      <div className="analytics-cards">

        {
          analyticsCards.map(
            (card, index) => (

              <div
                className="analytics-card"
                key={index}
              >

                <div className="card-icon">
                  {card.icon}
                </div>

                <h3>{card.title}</h3>

                <h1>{card.value}</h1>

              </div>

            )
          )
        }

      </div>

      
      
    </div>
  );
}

export default DashboardSection;