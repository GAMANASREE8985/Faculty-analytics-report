import React from "react";

function Sidebar({ setActiveSection }) {

  return (

    <div className="employee-sidebar">

      <h2>Faculty Portal</h2>

      <ul>

        <li
          onClick={() =>
            setActiveSection("dashboard")
          }
        >
          📊 Dashboard
        </li>

        <li
          onClick={() =>
            setActiveSection("sessions")
          }
        >
          📚 Sessions
        </li>

        <li
          onClick={() =>
            setActiveSection("analytics")
          }
        >
          📈 Analytics
        </li>

        <li
          onClick={() =>
            setActiveSection("roles")
          }
        >
          👨‍🏫 Roles
        </li>

      </ul>

    </div>
  );
}

export default Sidebar;