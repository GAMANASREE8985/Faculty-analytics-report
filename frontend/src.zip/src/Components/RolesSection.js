import React from "react";

function RolesSection({ roles }) {

  return (

    <div className="roles-card">

      <h2>Employee Roles</h2>

      {
        roles.map((role, index) => (

          <p key={index}>
            ✅ {role.position}
          </p>

        ))
      }

    </div>
  );
}

export default RolesSection;