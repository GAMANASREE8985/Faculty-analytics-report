import React from "react";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

function AnalyticsSection({ employeeData }) {

  // ============================================
  // SAFE ARTIFACT
  // ============================================

  const artifact =
    employeeData.artifacts?.[0] || {};

  // ============================================
  // SESSION HOURS CHART
  // ============================================

  const sessionChart = [

    {
      name: "Allocated",

      value:
        employeeData.sessions.reduce(
          (a, b) =>
            a +
            Number(
              b.session_allocated || 0
            ),
          0
        )
    },

    {
      name: "Taken",

      value:
        employeeData.sessions.reduce(
          (a, b) =>
            a +
            Number(
              b.session_taken || 0
            ),
          0
        )
    },

    {
      name: "Left",

      value:
        employeeData.sessions.reduce(
          (a, b) =>
            a +
            Number(
              b.session_left || 0
            ),
          0
        )
    }

  ];

  // ============================================
  // STATUS CHART
  // ============================================

  const statusChart = [

    {
      name: "Completed",

      value:
        employeeData.sessions.filter(
          (s) =>
            s.session_status ===
            "Completed"
        ).length
    },

    {
      name: "Pending",

      value:
        employeeData.sessions.filter(
          (s) =>
            s.session_status ===
            "Pending"
        ).length
    },

    {
      name: "Partial",

      value:
        employeeData.sessions.filter(
          (s) =>
            s.session_status ===
            "Partial"
        ).length
    }

  ];

  // ============================================
  // ARTIFACT CHART
  // ============================================

  const artifactChart = [

    {
      name: "QP",
      value: artifact.total_qp || 0
    },

    {
      name: "Capstone",
      value:
        artifact.total_capstone || 0
    },

    {
      name: "Courses",
      value:
        artifact.total_courses || 0
    },

    {
      name: "Certifications",
      value:
        artifact.total_cert || 0
    },

    {
      name: "Tools",
      value:
        artifact.total_tools || 0
    }

  ];

  // ============================================
  // UI
  // ============================================

  return (

    <div className="analytics-container">
        

      {/* SESSION HOURS */}

      <div className="chart-box">

        <h2>
          Session Hours Analytics
        </h2>

        <ResponsiveContainer
          width="100%"
          height={300}
        >

          <BarChart data={sessionChart}>

            <CartesianGrid
              strokeDasharray="3 3"
            />

            <XAxis dataKey="name" />

            <YAxis />

            <Tooltip />

            <Bar
              dataKey="value"
              fill="#2563eb"
            />

          </BarChart>

        </ResponsiveContainer>

      </div>

      {/* STATUS CHART */}

      <div className="chart-box">

        <h2>
          Session Status Analytics
        </h2>

        <ResponsiveContainer
          width="100%"
          height={300}
        >

          <PieChart>

            <Pie
              data={statusChart}
              dataKey="value"
              outerRadius={100}
              label
            >

              <Cell fill="#2563eb" />
              <Cell fill="#14b8a6" />
              <Cell fill="#f59e0b" />

            </Pie>

            <Tooltip />

          </PieChart>

        </ResponsiveContainer>

      </div>

      {/* ARTIFACT CHART */}

      <div className="chart-box">

        <h2>
          Artifact Analytics
        </h2>

        <ResponsiveContainer
          width="100%"
          height={350}
        >

          <BarChart data={artifactChart}>

            <CartesianGrid
              strokeDasharray="3 3"
            />

            <XAxis dataKey="name" />

            <YAxis />

            <Tooltip />

            <Bar
              dataKey="value"
              fill="#8b5cf6"
            />

          </BarChart>

        </ResponsiveContainer>

      </div>

    </div>
  );
}

export default AnalyticsSection;