// =====================================================
// frontend/src/Pages/HRDashboard.js
// =====================================================

import React, { useEffect, useState } from "react";

import axios from "axios";

import {

  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid

} from "recharts";

import "./HRDashboard.css";

function HRDashboard() {

  // =====================================================
  // STATE
  // =====================================================

  const [dashboardData, setDashboardData] =
    useState(null);

  // =====================================================
  // API
  // =====================================================

  useEffect(() => {

    axios.get(

      "http://127.0.0.1:5000/hr-dashboard"

    )

    .then((response) => {

      setDashboardData(response.data);

    })

    .catch((error) => {

      console.log(error);

    });

  }, []);

  // =====================================================
  // LOADING
  // =====================================================

  if (!dashboardData) {

    return <h1>Loading...</h1>;

  }

  // =====================================================
  // ROLE ANALYTICS
  // =====================================================

  const educatorCount =

    dashboardData.employees.filter(

      (e) => e.type === "Educator"

    ).length;

  const coEducatorCount =

    dashboardData.employees.filter(

      (e) => e.type === "Co-Educator"

    ).length;

  const invigilatorCount =

    dashboardData.employees.filter(

      (e) => e.type === "Invigilator"

    ).length;

  const roleChart = [

    {

      name: "Educator",

      value: educatorCount

    },

    {

      name: "Co-Educator",

      value: coEducatorCount

    },

    {

      name: "Invigilator",

      value: invigilatorCount

    }

  ];

  // =====================================================
  // SESSION STATUS
  // =====================================================

  const completedSessions =

    dashboardData.sessions.filter(

      (s) =>

        s.session_status ===
        "Completed"

    ).length;

  const pendingSessions =

    dashboardData.sessions.filter(

      (s) =>

        s.session_status ===
        "Pending"

    ).length;

  const partialSessions =

    dashboardData.sessions.filter(

      (s) =>

        s.session_status ===
        "Partial"

    ).length;

  // =====================================================
  // TOP BATCH
  // =====================================================

  const topBatch =

    dashboardData.sessions.length > 0

      ? dashboardData.sessions[0].batch_id

      : "N/A";

  // =====================================================
  // UI
  // =====================================================

  return (

    <div className="dashboard-container">

      {/* ================================================= */}
      {/* SIDEBAR */}
      {/* ================================================= */}

      <div className="sidebar">

        <h2>HR Analytics</h2>

        <ul>

          <li>🏠 Dashboard</li>
          <li>👨‍💼 Employees</li>
          <li>📚 Sessions</li>
          <li>📊 Analytics</li>
          <li>🏃 Performance</li>
          <li>📝 Reports</li>
          <li>⚙️ Settings</li>

        </ul>

      </div>

      {/* ================================================= */}
      {/* MAIN CONTENT */}
      {/* ================================================= */}

      <div className="main-content">

        {/* TOP BAR */}

        <div className="top-bar">

          <h1>

            Faculty Analytics Dashboard

          </h1>

          <button className="admin-btn">

            HR Admin

          </button>

        </div>

        {/* ================================================= */}
        {/* TOP CARDS */}
        {/* ================================================= */}

        <div className="cards">

          <div className="card">

            <h4>Total Employees</h4>

            <h2>

              {

                dashboardData.total_employees

              }

            </h2>

          </div>

          <div className="card">

            <h4>Total Sessions</h4>

            <h2>

              {

                dashboardData.total_sessions

              }

            </h2>

          </div>

          <div className="card">

            <h4>Completed</h4>

            <h2>

              {completedSessions}

            </h2>

          </div>

          <div className="card">

            <h4>Top Batch</h4>

            <h2>

              {topBatch}

            </h2>

          </div>

        </div>

        {/* ================================================= */}
        {/* ANALYTICS SECTION */}
        {/* ================================================= */}

        <div className="analytics-section">

          {/* ROLE CHART */}

          <div className="chart-card">

            <h3>

              Employee Roles

            </h3>

            <ResponsiveContainer
              width="100%"
              height={250}
            >

              <BarChart data={roleChart}>

                <CartesianGrid
                  strokeDasharray="3 3"
                />

                <XAxis dataKey="name" />

                <YAxis />

                <Tooltip />

                <Bar
                  dataKey="value"
                  fill="#2563eb"
                />

              </BarChart>

            </ResponsiveContainer>

          </div>

          {/* SESSION STATUS */}

          <div className="chart-card">

            <h3>

              Session Status

            </h3>

            <div className="status-box green">

              Complete

            </div>

            <div className="status-box blue">

              In Progress

            </div>

            <div className="status-box red">

              Pending

            </div>

          </div>

        </div>

        {/* ================================================= */}
        {/* EMPLOYEE TABLE */}
        {/* ================================================= */}

        <div className="table-container">

          <h2>

            Employee Details

          </h2>

          <table>

            <thead>

              <tr>

                <th>ID</th>
                <th>Name</th>
                <th>Type</th>
                <th>Role</th>
                <th>City</th>

              </tr>

            </thead>

            <tbody>

              {

                dashboardData.employees

                .slice(0, 10)

                .map((emp) => (

                  <tr key={emp.emp_id}>

                    <td>

                      {emp.emp_id}

                    </td>

                    <td>

                      {emp.name}

                    </td>

                    <td>

                      {emp.type}

                    </td>

                    <td>

                      HR

                    </td>

                    <td>

                      {emp.city}

                    </td>

                  </tr>

                ))

              }

            </tbody>

          </table>

        </div>

      </div>

    </div>

  );

}

export default HRDashboard;