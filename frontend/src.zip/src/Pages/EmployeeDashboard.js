import React, { useEffect, useState } from "react";

import axios from "axios";

import Sidebar from "../Components/Sidebar";
import Topbar from "../Components/Topbar";

import DashboardSection from "../Components/DashboardSection";
import AnalyticsSection from "../Components/AnalyticsSection";
import SessionsSection from "../Components/SessionsSection";
import RolesSection from "../Components/RolesSection";

import "../styles/EmployeeDashboard.css";

function EmployeeDashboard() {

  const [employeeData, setEmployeeData] =
    useState(null);

  const [activeSection, setActiveSection] =
    useState("dashboard");

  // ============================================
  // API CALL
  // ============================================

  useEffect(() => {

    const empId =
      localStorage.getItem("emp_id");

    axios
      .get(
        `http://127.0.0.1:5000/employee-dashboard/${empId}`
      )
      .then((response) => {

        setEmployeeData(
          response.data
        );

      })
      .catch((error) => {

        console.log(error);

      });

  }, []);

  // ============================================
  // LOADING
  // ============================================

  if (!employeeData) {

    return <h1>Loading...</h1>;

  }

  // ============================================
  // SAFE EMPLOYEE
  // ============================================

  const emp =
    employeeData.employee?.[0] || {};

  // ============================================
  // LOGOUT FUNCTION
  // ============================================

  const handleLogout = () => {

    localStorage.removeItem("emp_id");

    localStorage.removeItem("role");

    window.location.href = "/";

  };

  // ============================================
  // UI
  // ============================================

  return (

    <div className="employee-dashboard">

      {/* SIDEBAR */}

      <Sidebar
        setActiveSection={
          setActiveSection
        }
      />

      {/* MAIN SECTION */}

      <div className="employee-main">

        {/* TOPBAR */}

        <Topbar
          emp={emp}
          handleLogout={
            handleLogout
          }
        />

        {/* DASHBOARD */}

        {
          activeSection ===
          "dashboard" && (

            <DashboardSection
              employeeData={
                employeeData
              }
            />

          )
        }

        {/* ANALYTICS */}

        {
          activeSection ===
          "analytics" && (

            <AnalyticsSection
              employeeData={
                employeeData
              }
            />

          )
        }

        {/* SESSIONS */}

        {
          activeSection ===
          "sessions" && (

            <SessionsSection
              sessions={
                employeeData.sessions
              }
            />

          )
        }

        {/* ROLES */}

        {
          activeSection ===
          "roles" && (

            <RolesSection
              roles={
                employeeData.roles
              }
            />

          )
        }

      </div>

    </div>

  );
}

export default EmployeeDashboard;